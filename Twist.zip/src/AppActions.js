// import {createTypes, actionCreator} from 'redux-action-creator';

// export const AppActionTypes = createTypes([
//     'APP_ACTION', 
// ]);

// const someAction = actionCreator(AppActionTypes.APP_ACTION, 'someData');


// export const doSomething = (val) => {
//     return (dispatch) => {
//         dispatch(someAction(val));
//     };
// };

