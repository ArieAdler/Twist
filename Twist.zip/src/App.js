import React from 'react';
import {  BrowserRouter as Router,  Switch,  Route} from "react-router-dom";
import { connect } from 'react-redux'
import Dashboard from './Containers/Dashboard/Dashboard';
import Header from './Components/Header/Header';
import './App.css';

const App = ({dispatch}) => {
  return (
    <Router>
      <div className="appContent">
        <Header />
        <Switch>
          <Route exact path="/">
            <Dashboard />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

const mapStateToProps = (state) => ({
  
})

export default connect(mapStateToProps)(App);
