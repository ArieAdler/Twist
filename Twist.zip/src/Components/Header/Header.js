import React from 'react';
import icon from '../../images/icon.png';
import './Header.scss';

const Header = () => {
    return(
    <div className="header">
        <img src={icon} alt="logo"/>
    </div>
    )
}

export default Header;