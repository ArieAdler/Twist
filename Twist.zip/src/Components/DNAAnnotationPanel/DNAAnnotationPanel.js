import React, {useLayoutEffect, useState, useRef, useEffect} from 'react';
import DNARow from './Components/DNARow/DNARow';
import './DNAAnnotationPanel.scss';

const DNAAnnotationPanel = ({dna}) => {
    const [textWidth, setTextWidth] = useState(0);
    const [textPanelWidth, setTextPanelWidth] = useState(0);
    const [dnaLinesArr, setDNALinesArr] = useState([]);
    const dnaTextMeasureEl = useRef(null);
    const dnaTextPanelEl = useRef(null);
    useLayoutEffect(() => {
        setTextWidth(dnaTextMeasureEl.current.offsetWidth);
        function updateTextPanelSize() {
            setTextPanelWidth(dnaTextPanelEl.current.offsetWidth);
        }
          window.addEventListener('resize', updateTextPanelSize);
          updateTextPanelSize();
          return () => window.removeEventListener('resize', updateTextPanelSize);
    }, []);
    useEffect(() => {
        if(isNaN(textWidth / textPanelWidth)) return;
        const _numOfLines =  Math.ceil(textWidth / textPanelWidth);
        const _regex = new RegExp(`.{1,${_numOfLines}}`,"g")
        const _arr = dna.text.match(_regex).map((row,i, source) => {
            const index =(i + 1 < source.length ? i * row.length : dna.text.length - row.length) + 1
            return {
                data: row,
                index,
                annotations: dna.annotations.reduce((result, ann) => {
                    const start = ann.index;
                    const end = ann.index + ann.length - 1;
                    const anno = {}
                    if (start >= index && start <= (index + row.length)) {
                        anno.start = start - index;
                    }
                    if (end <= (index + row.length) && end >= index) { 
                        anno.end = end - index;
                    }
                    if (anno.start && !anno.end) {
                        anno.end = row.length;
                    } else if(anno.end && !anno.start){
                        anno.start = 1;
                    }
                    if (anno.start && anno.end) {
                        result.push(anno);
                        anno.tooltip = ann.tooltip;
                        return result;
                    }

                    return result;
                }, [])
            }
        });
        setDNALinesArr(_arr);
    }, [textWidth, textPanelWidth]);
    

    return (
        <>
            <div className="dnaTextMeasure" ref={dnaTextMeasureEl}>
                {dna.text}
            </div>
            <div className="dnaTextPanel" ref={dnaTextPanelEl}>
                {dnaLinesArr.map((item) => {
                    return <DNARow dnaRow={item}/>
                })}
            </div>
        </>
    )
}

export default DNAAnnotationPanel;