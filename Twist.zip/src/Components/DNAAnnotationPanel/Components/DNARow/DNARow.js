import React from 'react';

const DNARow = ({dnaRow}) => {
    return (
        <>
         <div className="dnaRow">
             <div className="dnaRowIndex">{dnaRow.index}</div>
             <div className="dnaRowData">
                {dnaRow.data.split('').map((char, index) => {
                    const annotation = dnaRow.annotations.reduce((result, item) => {
                        if ((index + 1) >= item.start && (index + 1) <= item.end) {
                            result.tooltip += `${result.count > 0 && ", " || ""}${item.tooltip}`;
                            result.count++;
                        }
                        return result;
                    }, {count: 0, tooltip: ""})
                    return <span className={annotation.count && `annotation ${annotation.count > 1 && "multiple" || ''} || ""`} title={annotation.tooltip}>{char}</span>
                })}
            </div>
        </div>
        </>
    )
}

export default DNARow;