

// The initial state of the App
const initialState = {
  loading: false
};

function appReducer(state = initialState, action) {
  let nextState;
  switch (action.type) {
    
    default:
      nextState = state;
  }
  return nextState;
}

export default appReducer;
